from pydantic import BaseModel, Field, HttpUrl, field_validator


class NavSchema(BaseModel):
    label: str
    icon: str | None = None
    group: str | None = None
    order: int = 0


class FrontendSchema(BaseModel):
    type: str = "module"
    enabled: bool = True
    entryUrl: HttpUrl
    mountFunction: str = "mount"
    integrity: str | None = None
    basePath: str = "/"


class BackendSchema(BaseModel):
    enabled: bool = True
    apiBaseUrl: HttpUrl
    healthEndpoint: str | None = "/health"


class AuthorizationSchema(BaseModel):
    requiredPermissions: list[str] = Field(default_factory=list)
    requiredFlags: list[str] = Field(default_factory=list)


class CompatibilitySchema(BaseModel):
    shellContractMin: str | None = None
    shellContractMax: str | None = None


class MetadataSchema(BaseModel):
    ownerTeam: str
    commitSha: str | None = None
    buildId: str | None = None
    releaseDate: str | None = None


class ReleaseManifestIn(BaseModel):
    manifestVersion: str = "1.0"
    featureKey: str
    displayName: str
    version: str
    environment: str
    route: str
    frontend: FrontendSchema
    backend: BackendSchema
    nav: NavSchema
    authorization: AuthorizationSchema = Field(default_factory=AuthorizationSchema)
    compatibility: CompatibilitySchema = Field(default_factory=CompatibilitySchema)
    metadata: MetadataSchema

    @field_validator("route")
    @classmethod
    def route_must_start_with_slash(cls, value: str) -> str:
        if not value.startswith("/"):
            raise ValueError("route must start with '/'")
        return value